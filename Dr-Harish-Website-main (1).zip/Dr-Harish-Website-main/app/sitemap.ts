import { MetadataRoute } from "next";

export const dynamic = "force-static";

const baseUrl = "https://drharishgowda.in";

const routes = [
  "",
  "/about",
  "/achievements",
  "/appendix-surgery",
  "/blog",
  "/book-appointment",
  "/contact",
  "/fissure-treatment",
  "/fistula-surgery",
  "/gallbladder-removal",
  "/hernia-repair",
  "/online-consultation",
  "/patient-resources",
  "/patient-stories",
  "/piles-surgery",
  "/pilonidal-sinus",
  "/privacy-policy",
  "/procedures",
  "/varicose-veins",
];

export default function sitemap(): MetadataRoute.Sitemap {
  return routes.map((route) => ({
    url: `${baseUrl}${route}`,
  }));
}
