import type { Metadata } from "next";
import ConditionIcon from "@/components/ConditionIcon";
import Image from "next/image";
import TrustindexWidget from "@/components/TrustindexWidget";
import Reveal from "@/components/Reveal";
import AnimatedCounter from "@/components/AnimatedCounter";
import SectionGlow from "@/components/SectionGlow";
import VideoTestimonial from "@/components/VideoTestimonial";
import Tag from "@/components/Tag";
import { WHATSAPP_HREF } from "@/lib/contact";

export const metadata: Metadata = {
  title: "Consultant Laparoscopic & GI Surgeon, Coloproctologist in Basavanagudi, Bangalore | Dr. Harish Gowda",
  description: "Dr. Harish Gowda treats piles, hernia, gallbladder and more with minimally invasive laparoscopic and laser surgery at HIMAS Hospital, Basavanagudi.",
  alternates: { canonical: "https://drharishgowda.in/" },
  openGraph: {
    title: "Consultant Laparoscopic & GI Surgeon, Coloproctologist in Basavanagudi, Bangalore | Dr. Harish Gowda",
    description: "Dr. Harish Gowda treats piles, hernia, gallbladder and more with minimally invasive laparoscopic and laser surgery at HIMAS Hospital, Basavanagudi.",
    url: "https://drharishgowda.in/",
    type: "website",
  },
};

const CONDITIONS = [
  { n: "01", key: "piles", name: "Piles", href: "/piles-surgery", desc: "Painless laser piles treatment, same-day discharge." },
  { n: "02", key: "hernia", name: "Hernia", href: "/hernia-repair", desc: "Laparoscopic hernia repair for patients across South Bangalore." },
  { n: "03", key: "gallbladder", name: "Gallbladder", href: "/gallbladder-removal", desc: "Keyhole gallbladder surgery, home the same day." },
  { n: "04", key: "fissure", name: "Fissure", href: "/fissure-treatment", desc: "Laser fissure treatment for patients in Jayanagar and JP Nagar." },
  { n: "05", key: "fistula", name: "Fistula", href: "/fistula-surgery", desc: "Complex fistula surgery, trusted across South Bangalore." },
  { n: "06", key: "appendix", name: "Appendix", href: "/appendix-surgery", desc: "Emergency laparoscopic appendix surgery in Basavanagudi." },
  { n: "07", key: "varicose-veins", name: "Varicose Veins", href: "/varicose-veins", desc: "Laser varicose vein treatment near Banashankari and BTM Layout." },
  { n: "08", key: "pilonidal-sinus", name: "Pilonidal Sinus", href: "/pilonidal-sinus", desc: "Laser and minimally invasive treatment, lower recurrence." },
] as const;

export default function Page() {
  return (
    <>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: "{\"@context\": \"https://schema.org\", \"@type\": \"Physician\", \"name\": \"Dr. Harish Gowda\", \"image\": \"https://drharishgowda.in/images/doctor/headshot.jpg\", \"telephone\": \"+917899824417\", \"medicalSpecialty\": [\"Surgery\", \"Gastrointestinal Surgery\", \"Laparoscopic Surgery\"], \"alumniOf\": [{\"@type\": \"CollegeOrUniversity\", \"name\": \"Bengaluru Medical College\"}, {\"@type\": \"CollegeOrUniversity\", \"name\": \"Mysore Medical College\"}], \"memberOf\": [\"Association of Surgeons of India\", \"Indian Association of Gastrointestinal Endo-Surgeons\", \"Association of Minimal Access Surgeons of India\"], \"award\": [\"Gold Medal, Diploma in Minimal Access Surgery, WALS\", \"Young Surgeon Award\"], \"worksFor\": {\"@type\": \"Hospital\", \"name\": \"HIMAS Hospital\", \"address\": {\"@type\": \"PostalAddress\", \"streetAddress\": \"No. 3 Kariyappa Road, Opp. Krishna Rao Park, Basavanagudi\", \"addressLocality\": \"Bangalore\", \"postalCode\": \"560004\", \"addressCountry\": \"IN\"}}, \"url\": \"https://drharishgowda.in\"}" }}
      />
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: "{\"@context\": \"https://schema.org\", \"@type\": \"LocalBusiness\", \"name\": \"Dr. Harish Gowda \\u2014 HIMAS Hospital\", \"telephone\": \"+917899824417\", \"address\": {\"@type\": \"PostalAddress\", \"streetAddress\": \"No. 3 Kariyappa Road, Opp. Krishna Rao Park, Basavanagudi\", \"addressLocality\": \"Bangalore\", \"postalCode\": \"560004\", \"addressCountry\": \"IN\"}, \"areaServed\": [\"Basavanagudi\", \"Jayanagar\", \"JP Nagar\", \"Banashankari\", \"BTM Layout\", \"Bangalore\"], \"url\": \"https://drharishgowda.in\"}" }}
      />

      {/* HERO */}
      <section className="relative overflow-hidden border-b border-[#d9d1c0] bg-[linear-gradient(135deg,_#f8f3e8_0%,_#f1e8d9_100%)] px-5 py-16 text-[#223126] sm:px-8 sm:py-24 lg:py-28">
        <div
          aria-hidden
          className="pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_top_left,_rgba(111,132,98,0.10),_transparent_42%),radial-gradient(circle_at_bottom_right,_rgba(95,111,83,0.08),_transparent_38%)]"
        />
        <div className="relative mx-auto grid max-w-7xl items-center gap-12 lg:grid-cols-[0.95fr_1.05fr] lg:gap-16">
          <div className="max-w-2xl">
            <Reveal delay={0} instant>
              <h1 className="font-serif text-[2.7rem] font-bold leading-[0.95] tracking-[-0.02em] text-[#223126] sm:text-[3.6rem] lg:text-[4.5rem]">
                Laparoscopic &amp; GI Surgeon in Basavanagudi, Bangalore
              </h1>
            </Reveal>
            <Reveal delay={150} instant>
              <p className="mt-6 max-w-xl text-[15px] leading-relaxed text-[#4b4a43]">
                With 24+ years of surgical experience, Dr. Harish Gowda combines deep clinical judgment with minimally invasive technique to help patients recover with less anxiety and more certainty.
              </p>
              <div className="mt-8 flex flex-wrap items-center gap-3 sm:gap-4">
                <a
                  href="https://appt.link/meet-with-dr-harish-ns"
                  target="_blank"
                  rel="noopener"
                  className="rounded-full bg-[#2f3c2f] px-6 py-3.5 text-sm font-semibold text-[#f8f3e8] shadow-[0_14px_30px_-12px_rgba(0,0,0,0.28)] transition hover:-translate-y-0.5 hover:bg-[#253129]"
                >
                  Book Consultation
                </a>
                <a
                  href={WHATSAPP_HREF}
                  target="_blank"
                  rel="noopener"
                  className="rounded-full border border-[#4a5a3d]/20 px-5 py-3.5 text-sm font-medium text-[#4a5a3d] transition hover:border-[#4a5a3d] hover:bg-white/70"
                >
                  Call on WhatsApp
                </a>
              </div>
            </Reveal>
            <Reveal delay={280} instant>
              <div className="mt-8 flex flex-wrap gap-x-6 gap-y-3 border-t border-[#cbbda1]/70 pt-5 text-sm text-[#40523b]">
                <div className="flex items-center gap-2">
                  <span className="font-serif text-[1.35rem] tracking-[-0.02em] text-[#304127]">
                    <AnimatedCounter target={24} suffix="" duration={1200} />
                    <span className="ml-1 text-[#6a7b59]">+</span>
                  </span>
                  <span className="font-mono text-[10px] uppercase tracking-[0.24em]">Years experience</span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="font-serif text-[1.35rem] tracking-[-0.02em] text-[#304127]">
                    <AnimatedCounter target={100000} suffix="" duration={1500} />
                    <span className="ml-1 text-[#6a7b59]">+</span>
                  </span>
                  <span className="font-mono text-[10px] uppercase tracking-[0.24em]">Patients treated</span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="font-serif text-[1.35rem] tracking-[-0.02em] text-[#304127]">Gold</span>
                  <span className="font-mono text-[10px] uppercase tracking-[0.24em]">Medalist</span>
                </div>
              </div>
            </Reveal>
          </div>

          <Reveal delay={120} instant>
            <div className="relative mx-auto w-full max-w-[480px] lg:ml-auto lg:mr-0 lg:max-w-[520px]">
              <div className="absolute inset-4 rounded-[2.2rem] bg-[linear-gradient(135deg,_rgba(111,132,98,0.12),_rgba(70,79,61,0.05))]" />
              <div className="relative overflow-hidden rounded-[2.2rem] border border-[#d8cab0] bg-[#efe7d9] p-3 shadow-[0_28px_80px_-28px_rgba(33,35,32,0.35)]">
                <div className="relative aspect-[4/5] overflow-hidden rounded-[1.7rem]">
                  <Image
                    src="/images/doctor/harish-sir.jpg"
                    alt="Dr. Harish Gowda at HIMAS Hospital, Basavanagudi"
                    fill
                    priority
                    className="object-cover [filter:saturate(0.95)_contrast(1.05)]"
                    sizes="(min-width: 1024px) 480px, 90vw"
                  />
                  <div
                    aria-hidden
                    className="pointer-events-none absolute inset-0 bg-gradient-to-t from-[#172118]/75 via-[#172118]/10 to-transparent"
                  />
                  <div className="absolute bottom-0 left-0 right-0 p-6 sm:p-8">
                    <p className="font-mono text-[10px] uppercase tracking-[0.32em] text-[#f1e6c8]">Founder &amp; Chief Surgeon</p>
                    <p className="mt-2 text-lg font-semibold text-white sm:text-xl">HIMAS Hospital, Basavanagudi</p>
                  </div>
                </div>
              </div>
            </div>
          </Reveal>
        </div>
      </section>

      {/* TICKER */}
      <div className="overflow-hidden border-b border-[#f4ebd0]/15 bg-[linear-gradient(135deg,_#24331f_0%,_#364a2f_100%)] py-3">
        <div className="flex w-max animate-marquee items-center gap-10 whitespace-nowrap font-mono text-[11px] uppercase tracking-[0.14em] text-[#f4ebd0]">
          {Array.from({ length: 2 }).map((_, i) => (
            <div key={i} className="flex items-center gap-10">
              <span>Same-Day Discharge</span>
              <span className="text-[#9da97f]">&#9670;</span>
              <span>1,00,000+ Patients Treated</span>
              <span className="text-[#9da97f]">&#9670;</span>
              <span>Founder &amp; Chief Surgeon, HIMAS Hospital</span>
              <span className="text-[#9da97f]">&#9670;</span>
              <span>Kannada &amp; English Consultations</span>
              <span className="text-[#9da97f]">&#9670;</span>
              <span>Gold Medalist, WALS</span>
              <span className="text-[#9da97f]">&#9670;</span>
            </div>
          ))}
        </div>
      </div>

      {/* STATS — serif numerals with a brass "+", not plain mono digits */}
      <section className="border-b border-stone-200 bg-[#fcfaf5] px-5 py-12 sm:px-8">
        <Reveal>
          <div className="mx-auto grid max-w-2xl grid-cols-3 gap-y-8 text-center sm:divide-x sm:divide-stone-200">
            <div>
              <div className="stat-figure text-4xl text-[#40523b] sm:text-5xl">
                <AnimatedCounter target={24} suffix="" />
                <span className="stat-plus">+</span>
              </div>
              <div className="mt-2 text-[11px] font-medium uppercase tracking-wide text-stone-500">Years Experience</div>
            </div>
            <div>
              <div className="stat-figure text-4xl text-[#40523b] sm:text-5xl">1</div>
              <div className="mt-2 text-[11px] font-medium uppercase tracking-wide text-stone-500">Day Discharge</div>
            </div>
            <div>
              <div className="stat-figure text-4xl text-[#40523b] sm:text-5xl">
                100<span className="stat-plus">%</span>
              </div>
              <div className="mt-2 text-[11px] font-medium uppercase tracking-wide text-stone-500">Personally Performed</div>
            </div>
          </div>
        </Reveal>
      </section>

      {/* TRUST NARRATIVE — text + environment photo, so it isn't a bare text block */}
      <section className="bg-[#f7f2e8] px-5 py-16 sm:px-8">
        <Reveal>
          <div className="mx-auto grid max-w-5xl items-center gap-10 md:grid-cols-[1fr_0.85fr]">
            <div>
              <span className="font-mono text-[11px] uppercase tracking-[0.2em] text-[#4b5d44]">The Practice</span>
              <h2 className="mt-3 font-serif text-3xl font-bold tracking-tight text-slate-900 sm:text-4xl">
                A surgeon Basavanagudi has trusted for years
              </h2>
              <p className="mt-4 border-l-2 border-[#4b5d44] pl-5 text-[15px] leading-relaxed text-stone-600">
                Dr. Harish Gowda is a Senior Laparoscopic and Gastrointestinal Surgeon with 24+ years of experience, and the Founder and Chief Surgeon at HIMAS Hospital, No. 3 Kariyappa Road, Basavanagudi. He specialises in minimally invasive surgery for conditions many patients put off out of fear or embarrassment, until they can&apos;t anymore &mdash; most procedures are completed in under an hour with same-day discharge and no large incisions. He is the only surgeon in Basavanagudi to run his own dedicated surgical hospital, and unlike large chain hospitals, every single procedure is performed by Dr. Harish Gowda personally, never delegated to a junior surgeon.
              </p>
              <a href="/about" className="link-underline mt-5 inline-flex items-center gap-1 text-sm font-medium text-[#4b5d44]">
                Read the full story &rarr;
              </a>
            </div>
            <div className="relative mx-auto aspect-[4/5] w-full max-w-sm overflow-hidden rounded-sm border border-stone-200 shadow-elevate-lg">
              <Image
                src="/images/doctor/consulation-room.webp"
                alt="Consultation room at HIMAS Hospital, Basavanagudi"
                fill
                className="object-cover"
                sizes="(min-width: 768px) 380px, 80vw"
              />
            </div>
          </div>
        </Reveal>
      </section>

      {/* CONDITIONS — oversized editorial index, not a small feature-card grid */}
      <section className="relative overflow-hidden bg-[linear-gradient(135deg,_#24331f_0%,_#364a2f_100%)] px-5 py-16 text-[#f7f2e8] sm:px-8 sm:py-20">
        <SectionGlow />
        <Reveal className="relative mx-auto max-w-4xl">
          <span className="font-mono text-[11px] uppercase tracking-[0.2em] text-[#dfe8cb]">Index of Conditions</span>
          <h2 className="mt-3 font-serif text-3xl font-bold tracking-tight text-[#f7f2e8] sm:text-4xl">Conditions we treat</h2>
          <div className="mt-10 divide-y divide-white/10 border-t border-white/10">
            {CONDITIONS.map((c) => (
              <a
                key={c.href}
                href={c.href}
                className="group grid grid-cols-[3.5rem_1fr_auto] items-center gap-4 py-5 transition hover:bg-white/[0.08] sm:grid-cols-[4.5rem_auto_1fr_auto] sm:gap-6 sm:px-4"
              >
                <span className="stat-figure text-2xl text-white/25 sm:text-3xl">{c.n}</span>
                <span className="hidden sm:block">
                  <ConditionIcon name={c.key} size={72} />
                </span>
                <span>
                  <h3 className="font-serif text-xl font-bold text-[#f7f2e8] sm:text-2xl">{c.name}</h3>
                  <p className="mt-0.5 text-[13px] leading-relaxed text-[#cfd6b8]">{c.desc}</p>
                </span>
                <span className="flex items-center gap-1 text-xs font-medium text-[#f4ebd0] opacity-0 transition group-hover:translate-x-1 group-hover:opacity-100">
                  Learn more &rarr;
                </span>
              </a>
            ))}
          </div>
        </Reveal>
      </section>

      {/* VIDEO TESTIMONIALS */}
      <section className="bg-[#f7f2e8] px-5 py-16 sm:px-8">
        <Reveal>
          <div className="mx-auto max-w-3xl text-center">
            <span className="font-mono text-[11px] uppercase tracking-[0.2em] text-[#4b5d44]">Patient Voices</span>
            <h2 className="mt-3 font-serif text-3xl font-bold tracking-tight text-slate-900 sm:text-4xl">What Our Patients Say</h2>
            <p className="mt-3 text-[15px] leading-relaxed text-stone-600">Real recoveries, in their own words, shared with consent.</p>
          </div>
          <div className="mx-auto mt-8 grid max-w-4xl grid-cols-1 gap-5 sm:grid-cols-3">
            {[
              { tag: "Piles Surgery", youtubeId: "FA00KLtJXpI" },
              { tag: "Hernia Repair", youtubeId: "FcWRu2MixXc" },
              { tag: "Gallbladder Surgery", youtubeId: "4CtP-kCb0D8" },
            ].map((slot) => (
              <VideoTestimonial key={slot.tag} youtubeId={slot.youtubeId} tag={slot.tag} />
            ))}
          </div>
          <p className="mt-7 text-center">
            <a href="/patient-stories" className="link-underline text-xs font-medium text-[#4b5d44]">
              Watch more patient stories &rarr;
            </a>
          </p>
        </Reveal>
      </section>

      {/* GOOGLE REVIEWS */}
      <section className="bg-[#f7f2e8] px-5 py-16 sm:px-8">
        <Reveal>
          <span className="block text-center font-mono text-[11px] uppercase tracking-[0.2em] text-[#4b5d44]">Verified on Google</span>
          <h2 className="mt-3 text-center font-serif text-3xl font-bold tracking-tight text-slate-900 sm:text-4xl">Rated Excellent on Google</h2>
          <div className="mx-auto mt-8 max-w-5xl">
            <TrustindexWidget />
          </div>
          <p className="mt-6 text-center">
            <a href="https://share.google/yH8m8mTSkXy8PTUvY" target="_blank" rel="noopener" className="link-underline text-xs font-medium text-[#4b5d44]">
              View Dr. Harish Gowda&apos;s full profile on Google &rarr;
            </a>
          </p>
        </Reveal>
      </section>

      {/* KANNADA + ONLINE CONSULT — one dark section, two columns, instead of two stacked strips */}
      <section className="relative overflow-hidden border-y border-[#f4ebd0]/15 bg-[linear-gradient(135deg,_#24331f_0%,_#364a2f_100%)] px-5 py-14 text-[#f7f2e8] sm:px-8">
        <div className="mx-auto grid max-w-5xl gap-10 sm:grid-cols-2 sm:divide-x sm:divide-white/10">
          <div className="text-center sm:pr-10 sm:text-left">
            <span className="font-mono text-[11px] uppercase tracking-[0.2em] text-[#f4ebd0]">Kannada &amp; English</span>
            <h2 className="mt-2 font-serif text-2xl font-bold tracking-tight text-[#f7f2e8] sm:text-3xl">ಕನ್ನಡದಲ್ಲಿ ಸಮಾಲೋಚನೆ ಲಭ್ಯವಿದೆ</h2>
            <p className="mt-2 text-sm text-[#dfe8cb]">Explain your symptoms in the language you&apos;re most comfortable in.</p>
          </div>
          <div className="text-center sm:pl-10 sm:text-left">
            <span className="font-mono text-[11px] uppercase tracking-[0.2em] text-[#f4ebd0]">Remote Consult</span>
            <h3 className="mt-2 font-serif text-2xl font-bold tracking-tight text-[#f7f2e8] sm:text-3xl">Can&apos;t visit in person?</h3>
            <p className="mt-2 text-sm text-[#dfe8cb]">Book a secure video consultation from anywhere in Bangalore or beyond.</p>
            <a
              href="/online-consultation"
              className="mt-4 inline-flex rounded-full bg-[#f4ebd0] px-5 py-2.5 text-sm font-medium text-[#2f3c2f] transition hover:-translate-y-0.5 hover:bg-[#efe3bf]"
            >
              Book Online Consultation
            </a>
          </div>
        </div>
      </section>

      {/* SERVICE AREA — area pills instead of a plain paragraph, so it isn't just more body text */}
      <section className="border-t border-stone-200 bg-[#f8f3ea] px-5 py-14 text-center sm:px-8">
        <h2 className="font-serif text-2xl font-bold tracking-tight text-slate-900 sm:text-3xl">Serving Basavanagudi and South Bangalore</h2>
        <p className="mx-auto mt-3 max-w-2xl text-sm leading-relaxed text-stone-600">
          Dr. Harish Gowda at HIMAS Hospital, No. 3 Kariyappa Road, Basavanagudi, is the nearest laparoscopic and GI surgeon for patients across South Bangalore. Same-week appointments and same-day emergency consultations available.
        </p>
        <div className="mx-auto mt-6 flex max-w-2xl flex-wrap justify-center gap-2.5">
          {["Basavanagudi", "Jayanagar", "JP Nagar", "Banashankari", "BTM Layout", "Girinagar", "Kanakapura Road"].map((area) => (
            <Tag key={area}>{area}</Tag>
          ))}
        </div>
      </section>
    </>
  );
}
