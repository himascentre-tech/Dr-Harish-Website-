import type { Metadata } from "next";
import ConditionPage from "@/components/ConditionPage";
import { PHONE_DISPLAY, PHONE_TEL } from "@/lib/contact";

export const metadata: Metadata = {
  title: "Pilonidal Sinus Surgery in Basavanagudi, Bangalore | Dr. Harish Gowda",
  description: "Laser and minimally invasive pilonidal sinus treatment at HIMAS Hospital, Basavanagudi, with an emphasis on lower recurrence and faster return to sitting and desk work.",
  alternates: { canonical: "https://drharishgowda.in/pilonidal-sinus" },
  openGraph: {
    title: "Pilonidal Sinus Surgery in Basavanagudi, Bangalore | Dr. Harish Gowda",
    description: "Laser and minimally invasive pilonidal sinus treatment at HIMAS Hospital, Basavanagudi, with an emphasis on lower recurrence and faster return to sitting and desk work.",
    url: "https://drharishgowda.in/pilonidal-sinus",
    type: "website",
  },
};

export default function Page() {
  return (
    <ConditionPage
      data={{
        icon: "pilonidal-sinus",
        breadcrumbLabel: "Pilonidal Sinus",
        eyebrow: "Pilonidal Sinus Treatment in Basavanagudi",
        title: "Pilonidal Sinus Surgery in Basavanagudi, Bangalore",
        description: "Laser and minimally invasive treatment for pilonidal sinus at HIMAS Hospital, Basavanagudi, focused on lower recurrence and getting back to a desk job faster.",
        symptoms: [
          "A small pit or opening at the top of the buttock crease",
          "Pain and swelling near the tailbone, especially after sitting",
          "Pus or fluid discharge from the area",
          "Recurring infection or an abscess at the same spot",
        ],
        practiceHeading: "In my practice, here's what pilonidal sinus usually looks like",
        practiceNote: "Most patients I see are in their 20s and 30s, often with desk jobs or long hours of sitting, and come in after the same spot near the tailbone has flared up more than once. A small, quiet sinus can sometimes be managed conservatively, but one that keeps recurring or discharging is best treated surgically before it turns into a larger abscess.",
        treatmentHeading: "How I treat it",
        treatmentNote: "Depending on the size and complexity of the sinus tract, I offer laser sinus ablation for smaller tracts or minimally invasive excision for more established ones. Both are aimed at lower recurrence and a quicker return to sitting comfortably and working.",
        timeline: [
          { label: "Day 0–1", text: "Discharge" },
          { label: "Week 1–2", text: "Wound care, limited sitting" },
          { label: "Week 3–4", text: "Back to desk work" },
          { label: "Week 6", text: "Full recovery" },
        ],
        faqs: [
          { q: "Can pilonidal sinus be treated without surgery?", a: "A small, non-infected sinus can sometimes be managed with hygiene and hair removal around the area. A sinus that has become infected or keeps recurring generally needs surgical treatment." },
          { q: "Is laser treatment for pilonidal sinus painful?", a: "Laser ablation is minimally invasive with less post-operative pain than traditional excision, and most patients go home the same day." },
          { q: "Does pilonidal sinus come back after surgery?", a: "Recurrence is possible with any technique, which is why wound care and hygiene in the weeks after surgery matter as much as the procedure itself." },
        ],
        related: [
          { href: "/piles-surgery", text: "Pilonidal sinus is sometimes confused with other conditions near the tailbone. Read about Piles Treatment →" },
          { href: "https://himashospital.in/facility", text: "For details on our operation theatre and post-surgical care infrastructure, visit HIMAS Hospital Facilities →" },
        ],
        cta: {
          heading: "Living with a recurring sinus near your tailbone?",
          text: "Get it assessed before it turns into another abscess.",
          primaryLabel: `Call ${PHONE_DISPLAY}`,
          primaryHref: `tel:${PHONE_TEL}`,
        },
        schemas: [
          "{\"@context\": \"https://schema.org\", \"@type\": \"MedicalProcedure\", \"name\": \"Pilonidal Sinus Surgery in Basavanagudi, Bangalore\", \"procedureType\": \"https://schema.org/PercutaneousProcedure\", \"bodyLocation\": \"Sacrococcygeal region\", \"preparation\": \"Consultation with Dr. Harish Gowda and pre-surgery workup as advised.\", \"followup\": \"Full recovery\", \"url\": \"https://drharishgowda.in/pilonidal-sinus.html\"}",
          "{\"@context\": \"https://schema.org\", \"@type\": \"FAQPage\", \"mainEntity\": [{\"@type\": \"Question\", \"name\": \"Can pilonidal sinus be treated without surgery?\", \"acceptedAnswer\": {\"@type\": \"Answer\", \"text\": \"A small, non-infected sinus can sometimes be managed with hygiene and hair removal around the area. A sinus that has become infected or keeps recurring generally needs surgical treatment.\"}}, {\"@type\": \"Question\", \"name\": \"Is laser treatment for pilonidal sinus painful?\", \"acceptedAnswer\": {\"@type\": \"Answer\", \"text\": \"Laser ablation is minimally invasive with less post-operative pain than traditional excision, and most patients go home the same day.\"}}, {\"@type\": \"Question\", \"name\": \"Does pilonidal sinus come back after surgery?\", \"acceptedAnswer\": {\"@type\": \"Answer\", \"text\": \"Recurrence is possible with any technique, which is why wound care and hygiene in the weeks after surgery matter as much as the procedure itself.\"}}]}",
          "{\"@context\": \"https://schema.org\", \"@type\": \"BreadcrumbList\", \"itemListElement\": [{\"@type\": \"ListItem\", \"position\": 1, \"name\": \"Home\", \"item\": \"https://drharishgowda.in/index.html\"}, {\"@type\": \"ListItem\", \"position\": 2, \"name\": \"Procedures\", \"item\": \"https://drharishgowda.in/procedures.html\"}, {\"@type\": \"ListItem\", \"position\": 3, \"name\": \"Pilonidal Sinus\", \"item\": \"https://drharishgowda.in/pilonidal-sinus.html\"}]}",
        ],
      }}
    />
  );
}
