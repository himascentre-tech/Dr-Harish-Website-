import Link from "next/link";
import SectionGlow from "@/components/SectionGlow";
import { SOCIAL_LINKS, SocialIcon } from "@/components/SocialIcons";
import { PHONE_DISPLAY, PHONE_TEL } from "@/lib/contact";

export default function Footer() {
  return (
    <footer className="relative overflow-hidden border-t border-stone-200 bg-slate-900 text-stone-300">
      <SectionGlow />
      <div className="relative mx-auto grid max-w-6xl grid-cols-1 gap-10 px-5 py-14 sm:grid-cols-3 sm:px-8">
        <div>
          <span className="font-serif text-2xl font-bold italic text-white" style={{ letterSpacing: "-0.01em" }}>
            Dr. Harish Gowda
          </span>
          <div className="mt-4 flex items-start gap-2.5 text-sm leading-relaxed">
            <span className="mt-0.5 text-teal-400">&#128205;</span>
            <span>
              HIMAS Hospital, No. 3 Kariyappa Road, Opp. Krishna Rao Park,
              Basavanagudi, Bangalore 560004
            </span>
          </div>
          <div className="mt-2.5 flex items-center gap-2.5 text-sm">
            <span className="text-teal-400">&#128222;</span>
            <a href={`tel:${PHONE_TEL}`} className="font-mono text-[13px] hover:text-white">
              {PHONE_DISPLAY}
            </a>
          </div>
          <div className="mt-5 flex items-center gap-3">
            {SOCIAL_LINKS.map((social) => (
              <a
                key={social.label}
                href={social.href}
                target="_blank"
                rel="noopener"
                aria-label={`Dr. Harish Gowda on ${social.label}`}
                className="flex h-8 w-8 items-center justify-center rounded-full bg-white shadow-sm transition hover:-translate-y-0.5 hover:shadow-md"
              >
                <SocialIcon platform={social.platform} size={15} gradientId="ig-gradient-footer" />
              </a>
            ))}
          </div>
        </div>

        <div>
          <span className="text-xs font-semibold uppercase tracking-widest text-stone-500">
            Sitemap
          </span>
          <ul className="mt-4 space-y-2.5 text-sm">
            <li><Link href="/about" className="link-underline hover:text-white">About</Link></li>
            <li><Link href="/procedures" className="link-underline hover:text-white">Procedures</Link></li>
            <li><Link href="/achievements" className="link-underline hover:text-white">Achievements</Link></li>
            <li><Link href="/patient-stories" className="link-underline hover:text-white">Patient Stories</Link></li>
            <li><Link href="/blog" className="link-underline hover:text-white">Blog</Link></li>
            <li><Link href="/patient-resources" className="link-underline hover:text-white">FAQ</Link></li>
            <li><Link href="/contact" className="link-underline hover:text-white">Contact</Link></li>
          </ul>
        </div>

        <div>
          <span className="text-xs font-semibold uppercase tracking-widest text-stone-500">
            Legal
          </span>
          <ul className="mt-4 space-y-2.5 text-sm">
            <li><Link href="/privacy-policy" className="link-underline hover:text-white">Privacy Policy</Link></li>
          </ul>
          <span className="mt-6 block text-xs font-semibold uppercase tracking-widest text-stone-500">
            Related
          </span>
          <ul className="mt-4 space-y-2.5 text-sm">
            <li>
              <a href="https://himashospital.in" className="link-underline hover:text-white">
                HIMAS Hospital facility site &rarr;
              </a>
            </li>
          </ul>
        </div>
      </div>
      <div className="border-t border-white/10 px-5 py-4 sm:px-8">
        <p className="mx-auto max-w-6xl font-mono text-[11px] text-stone-500">
          &copy; {new Date().getFullYear()} Dr. Harish Gowda &middot; HIMAS Hospital, Basavanagudi
        </p>
      </div>
    </footer>
  );
}
