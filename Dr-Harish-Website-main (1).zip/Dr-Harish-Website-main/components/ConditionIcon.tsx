import Image from "next/image";

export type ConditionKey =
  | "piles"
  | "hernia"
  | "gallbladder"
  | "fissure"
  | "fistula"
  | "appendix"
  | "varicose-veins"
  | "pilonidal-sinus";

/**
 * Hand-drawn line icons (see /public/icons/conditions) rendered inside a
 * colored badge. `size` controls the badge's diameter in px — the artwork
 * itself is scaled to ~72% of that so it keeps breathing room inside the
 * badge at any size.
 */
export default function ConditionIcon({
  name,
  size = 44,
}: {
  name: ConditionKey;
  size?: number;
}) {
  const artSize = Math.round(size * 0.72);
  return (
    <div
      className="flex shrink-0 items-center justify-center rounded-lg bg-teal-50 ring-1 ring-inset ring-black/5"
      style={{ width: size, height: size }}
    >
      <Image
        src={`/icons/conditions/${name}.png`}
        alt=""
        width={artSize}
        height={artSize}
        className="object-contain"
      />
    </div>
  );
}
